# Jenny Holidays Backend

This is the backend API for the Jenny Holidays e-commerce application.

## Features

- User authentication with JWT
- Product management
- Order processing
- Payment integration with Stripe
- Admin role support

## Setup

1. Copy .env.example to .env and fill in your environment variables.

2. Install dependencies:

3. Run database migrations:

4. Seed initial data:

5. Start the server:

## Environment Variables

- JWT_SECRET: Secret key for JWT signing
- DB_STORAGE: Path to SQLite database file
- STRIPE_SECRET_KEY: Stripe secret key
- STRIPE_PUBLISHABLE_KEY: Stripe publishable key
- PORT: Server port (default 5000)

## License

MIT