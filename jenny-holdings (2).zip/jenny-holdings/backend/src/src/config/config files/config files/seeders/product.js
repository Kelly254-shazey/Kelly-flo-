'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('Products', [
      {
        name: 'Beach Holiday Package',
        description: 'Relaxing beach holiday with all-inclusive services.',
        price: 15000,
        imageURL: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        name: 'Mountain Adventure',
        description: 'Explore mountains with guided tours and camping.',
        price: 12000,
        imageURL: 'https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=400&q=80',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        name: 'City Break',
        description: 'Discover city life with tours, shopping, and dining.',
        price: 8000,
        imageURL: 'https://images.unsplash.com/photo-1468071174046-657d9d351a40?auto=format&fit=crop&w=400&q=80',
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ]);
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('Products', null, {});
  }
};
