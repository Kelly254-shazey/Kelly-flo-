'use strict';

const bcrypt = require('bcrypt');

module.exports = {
  async up(queryInterface, Sequelize) {
    const passwordHash = await bcrypt.hash('adminPassword', 10);
    await queryInterface.bulkInsert('Users', [
      {
        email: 'admin@jennyholidays.com',
        passwordHash,
        role: 'admin',
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ]);
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('Users', { email: 'admin@jennyholidays.com' }, {});
  }
};