const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');
const { authenticateToken } = require('../middleware/auth');

router.post('/', authenticateToken, orderController.placeOrder);
router.get('/', authenticateToken, orderController.getUserOrders);

module.exports = router;