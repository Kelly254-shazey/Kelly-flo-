const { Order } = require('../models');

exports.placeOrder = async (req, res) => {
  try {
    const { items, totalPrice } = req.body;
    if (!items || !totalPrice) return res.status(400).json({ error: 'Missing order data' });
    const order = await Order.create({
      userId: req.user.id,
      items: JSON.stringify(items),
      totalPrice
    });
    res.status(201).json({ message: 'Order placed', orderId: order.id });
  } catch {
    res.status(500).json({ error: 'Failed to place order' });
  }
};

exports.getUserOrders = async (req, res) => {
  try {
    const orders = await Order.findAll({ where: { userId: req.user.id } });
    res.json(orders);
  } catch {
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
};