'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Order extends Model {
    static associate(models) {
      Order.belongsTo(models.User, { foreignKey: 'userId' });
    }
  }
  Order.init({
    userId: { type: DataTypes.INTEGER, allowNull: false },
    items: { type: DataTypes.TEXT, allowNull: false },
    totalPrice: { type: DataTypes.FLOAT, allowNull: false }
  }, {
    sequelize,
    modelName: 'Order',
  });
  return Order;
};