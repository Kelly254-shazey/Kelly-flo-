const { User, Order } = require('../models');

exports.getProfile = async (req, res) => {
  try {
    const user = await User.findByPk(req.user.id, { attributes: ['id', 'email', 'role'] });
    const orders = await Order.findAll({ where: { userId: req.user.id } });
    res.json({ user, orders });
  } catch {
    res.status(500).json({ error: 'Failed to fetch profile' });
  }
};