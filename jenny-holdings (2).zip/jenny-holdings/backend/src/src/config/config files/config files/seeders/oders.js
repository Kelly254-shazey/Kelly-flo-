'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('Orders', [
      {
        userId: 1, // assuming admin user seeded above has id=1
        items: JSON.stringify([
          { productId: 1, name: 'Beach Holiday Package', quantity: 2, price: 15000 }
        ]),
        totalPrice: 30000,
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ]);
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('Orders', null, {});
  }
};