# Jenny Holidays Frontend

This is the *React frontend* for the Jenny Holidays e-commerce application. It allows users to browse holiday packages, manage their cart, authenticate, and complete payments. Admin users can manage products via the Admin Panel.

---

## Features

- User signUP and login with JWT authentication
- Browse and search holiday packages
- Add products to shopping cart
- Secure checkout with Stripe payment integration
- User profile with order history
- Admin panel for managing products
- Responsive UI built with Material UI

---

## Project Structure

---

## Getting Started

### Prerequisites

- Node.js (v16 or higher recommended)
- npm or yarn package manager
- Running backend API (see backend README)

### Installation

1. Clone the repository:

2. Install dependencies:

3. Create a .env file in the root directory and add:

Replace the URL with your backend API URL if different.

### Running the App

Start the development server:

Open your browser at [http://localhost:3000](http://localhost:3000).

---

## Available Scripts

- npm start - Starts the development server
- npm run build - Builds the app for production
- npm test - Runs tests (if configured)

---

## Environment Variables

| Variable            | Description                      |
| ------------------- | --------------------------------|
| REACT_APP_API_URL   | Base URL for backend API         |

---

## Technologies Used

- React 18
- React Router v6
- Material UI
- Stripe.js & React Stripe.js
- JWT Authentication
- Fetch API for backend communication

---

## Contributing

Contributions are welcome! Please open an issue or submit a pull request.

---

## License

MIT License

---

## Contact

Your Name - [kelly123simiyu.com](mailto:kelly123simiyu.com)

Project Link: [https://github.com/kelly254-shazey/jenny-holidays-frontend](https://github.com/kelly254-shazey/jenny-holidays-frontend) 
