// src/pages/Profile/Profile.js

import React, { useEffect, useState } from 'react';
import {
  Typography,
  Box,
  List,
  ListItem,
  ListItemText,
  CircularProgress,
  Alert,
} from '@mui/material';
import { useAuth } from '../../contexts/AuthContext';

export default function Profile() {
  const { user } = useAuth();
  const [profileData, setProfileData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!user || !user.token) {
      setLoading(false);
      setError('User not authenticated');
      return;
    }

    const fetchProfile = async () => {
      try {
        const response = await fetch(
         ' ${process.env.REACT_APP_API_URL}/users/profile',
          {
            headers: {
              Authorization:' Bearer ${user.token}',
              'Content-Type': 'application/json',
            },
          }
        );

        if (!response.ok) {
          throw new Error('Error: ${response.status} ${response.statusText}');
        }

        const data = await response.json();
        setProfileData(data);
        setError(null);
      } catch (err) {
        setError(err.message || 'Failed to fetch profile data');
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, [user]);

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ maxWidth: 600, mx: 'auto', mt: 4 }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    );
  }

  if (!profileData) {
    return (
      <Box sx={{ maxWidth: 600, mx: 'auto', mt: 4 }}>
        <Typography variant="h6">No profile data available.</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ maxWidth: 600, mx: 'auto', mt: 4 }}>
      <Typography variant="h4" gutterBottom>
        Profile
      </Typography>
      <Typography variant="h6" gutterBottom>
        Email: {user.email}
      </Typography>

      <Typography variant="h5" sx={{ mt: 3, mb: 2 }}>
        Orders
      </Typography>

      {Array.isArray(profileData.orders) && profileData.orders.length > 0 ? (
        <List>
          {profileData.orders.map((order) => (
            <ListItem key={order.id} divider>
              <ListItemText
                primary={'Order #${order.id}'}
                secondary={`Total: KSH ${Number(order.totalPrice).toFixed(2)} - Items: ${
                  Array.isArray(order.items) ? order.items.length : 0
                }`}
              />
            </ListItem>
          ))}
        </List>
      ) : (
        <Typography>No orders found.</Typography>
      )}
    </Box>
  );
}
