import React, { useEffect, useState } from 'react';
import { fetchProducts } from '../../api/api';
import ProductCard from '../../components/ProductCard/ProductCard';
import { Grid, Typography } from '@mui/material';

export default function Home() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetchProducts()
      .then(setProducts)
      .catch(console.error);
  }, []);

  return (
    <>
      <Typography variant="h4" gutterBottom>Holiday Packages</Typography>
      <Grid container spacing={2}>
        {products.map(product => (
          <Grid item xs={12} sm={6} md={4} key={product.id}>
            <ProductCard product={product} />
          </Grid>
        ))}
      </Grid>
    </>
  );
}