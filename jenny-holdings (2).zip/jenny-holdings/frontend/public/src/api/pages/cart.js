import React, { useState } from 'react';
import { Typography, List, Button, Box } from '@mui/material';
import CartItem from '../../components/CartItem/CartItem';

export default function Cart() {
  const [cartItems, setCartItems] = useState(() => {
    const saved = localStorage.getItem('cart');
    return saved ? JSON.parse(saved) : [];
  });

  const removeItem = (id) => {
    const updated = cartItems.filter(item => item.id !== id);
    setCartItems(updated);
    localStorage.setItem('cart', JSON.stringify(updated));
  };

  const totalPrice = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <Box maxWidth={600} mx="auto" mt={4}>
      <Typography variant="h4" gutterBottom>Shopping Cart</Typography>
      {cartItems.length === 0 ? (
        <Typography>Your cart is empty.</Typography>
      ) : (
        <>
          <List>
            {cartItems.map(item => (
              <CartItem key={item.id} item={item} onRemove={removeItem} />
            ))}
          </List>
          <Typography variant="h6" sx={{ mt: 2 }}>
            Total: KSH {totalPrice.toFixed(2)}
          </Typography>
          {/* Add checkout button or link here */}
        </>
      )}
    </Box>
  );
}