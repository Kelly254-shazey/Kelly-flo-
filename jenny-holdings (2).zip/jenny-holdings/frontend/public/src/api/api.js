const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

export async function login(email, password) {
  const res = await fetch($,{API_BASE}/auth/login, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  if (!res.ok) throw new Error('Login failed');
  return res.json();
}

export async function signup(email, password) {
  const res = await fetch($,{API_BASE}/auth/signup, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  if (!res.ok) throw new Error('Signup failed');
  return res.json();
}

export async function fetchProducts() {
  const res = await fetch($,{API_BASE}/products);
  if (!res.ok) throw new Error('Failed to fetch products');
  return res.json();
}

// Add more API calls like placeOrder, getProfile, etc.