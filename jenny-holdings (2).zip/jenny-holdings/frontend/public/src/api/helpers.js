// src/utils/helpers.js

/**
 * Format a number as Kenyan Shilling currency string.
 * @param {number} amount - The amount to format.
 * @returns {string} Formatted currency string, e.g. "KSH 1,000.00"
 */
export function formatCurrency(amount) {
  if (typeof amount !== 'number') return '';
  return amount.toLocaleString('en-KE', {
    style: 'currency',
    currency: 'KES',
    minimumFractionDigits: 2,
  });
}

/**
 * Format a date string or Date object into a readable format.
 * @param {string|Date} date - Date string or Date object.
 * @returns {string} Formatted date, e.g. "May 14, 2025"
 */
export function formatDate(date) {
  if (!date) return '';
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('en-KE', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

/**
 * Capitalize the first letter of a string.
 * @param {string} str - Input string.
 * @returns {string} String with first letter capitalized.
 */
export function capitalizeFirstLetter(str) {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}