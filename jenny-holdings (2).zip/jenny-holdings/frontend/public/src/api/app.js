import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import { Container, AppBar, Toolbar, Typography, Button } from '@mui/material';
import { AuthProvider, useAuth } from './contexts/AuthContext';

import Home from './pages/Home/Home';
import Login from './pages/Login/Login';
import Signup from './pages/Signup/Signup';
import Cart from './pages/Cart/Cart';
import Profile from './pages/Profile/Profile';
import AdminPanel from './pages/AdminPanel/AdminPanel';

function Navigation() {
  const { user, logout } = useAuth();

  return (
    <AppBar position="static">
      <Toolbar>
        <Typography variant="h6" sx={{ flexGrow: 1 }}>
          Jenny Holidays
        </Typography>
        <Link to="/" style={{ color: 'inherit', textDecoration: 'none', marginRight: 15 }}>
          Home
        </Link>
        {user ? (
          <>
            <Link to="/profile" style={{ color: 'inherit', textDecoration: 'none', marginRight: 15 }}>
              Profile
            </Link>
            <Link to="/cart" style={{ color: 'inherit', textDecoration: 'none', marginRight: 15 }}>
              Cart
            </Link>
            {user.role === 'admin' && (
              <Link to="/admin" style={{ color: 'inherit', textDecoration: 'none', marginRight: 15 }}>
                Admin
              </Link>
            )}
            <Button color="inherit" onClick={logout}>
              Logout
            </Button>
          </>
        ) : (
          <>
            <Link to="/login" style={{ color: 'inherit', textDecoration: 'none', marginRight: 15 }}>
              Login
            </Link>
            <Link to="/signup" style={{ color: 'inherit', textDecoration: 'none' }}>
              Sign Up
            </Link>
          </>
        )}
      </Toolbar>
    </AppBar>
  );
}

function RequireAuth({ children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" />;
  return children;
}

function RequireAdmin({ children }) {
  const { user } = useAuth();
  if (!user || user.role !== 'admin') return <Navigate to="/" />;
  return children;
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Navigation />
        <Container sx={{ mt: 4 }}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/cart" element={<RequireAuth><Cart /></RequireAuth>} />
            <Route path="/profile" element={<RequireAuth><Profile /></RequireAuth>} />
            <Route path="/admin" element={<RequireAdmin><AdminPanel /></RequireAdmin>} />
            <Route path="*" element={<Typography variant="h5">Page Not Found</Typography>} />
          </Routes>
        </Container>
      </Router>
    </AuthProvider>
  );
}
