import React from 'react';
import { ListItem, ListItemText, IconButton } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';

export default function CartItem({ item, onRemove }) {
  return (
    <ListItem
      secondaryAction={
        <IconButton edge="end" aria-label="delete" onClick={() => onRemove(item.id)}>
          <DeleteIcon />
        </IconButton>
      }
    >
      <ListItemText
        primary={item.name}
        secondary={'Quantity: ${item.quantity} - Price: KSH ${(item.price * item.quantity).toFixed(2)}'}
      />
    </ListItem>
  );
}