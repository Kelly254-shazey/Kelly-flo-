import React from 'react';
import { Card, CardMedia, CardContent, Typography, Button } from '@mui/material';
import { formatCurrency,capitalizeFirstLetter } from '../.../utils/helpers';

export default function ProductCard({ product, onAddToCart }) {
  return (
    <Card>
      <CardMedia component="img" height="140" image={product.imageURL} alt={product.name} />
      <CardContent>
        <Typography variant="h6">{product.name}</Typography>
        <Typography variant="body2" color="text.secondary">{product.description}</Typography>
        <Typography variant="subtitle1" sx={{ mt: 1, fontWeight: 'bold' }}>
          KSH {product.price.toFixed(2)}
        </Typography>
        <Button variant="contained" fullWidth sx={{ mt: 1 }} onClick={() => onAddToCart(product)}>
          Add to Cart
        </Button>
      </CardContent>
    </Card>
  );
}